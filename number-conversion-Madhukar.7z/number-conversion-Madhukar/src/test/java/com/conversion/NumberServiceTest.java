package com.conversion;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;



import com.conversion.service.INumberService;
import com.conversion.service.impl.NumberServiceImpl;

import junit.framework.Assert;

@RunWith(MockitoJUnitRunner.class)
public class NumberServiceTest {
	
	@InjectMocks
	private INumberService numberService = new NumberServiceImpl(); 
	
	@SuppressWarnings("deprecation")
	@Test
	public void convertTest() throws Exception {
		Assert.assertEquals("Please provide valid number between 0 to 999,999,999", numberService.converter(999999999));
		
		Assert.assertEquals("nine thousand nine hundred ninety nine", numberService.converter(9999));
	}

}
