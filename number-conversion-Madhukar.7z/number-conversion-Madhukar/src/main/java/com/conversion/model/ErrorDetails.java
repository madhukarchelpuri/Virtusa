package com.conversion.model;

import java.util.Date;

public class ErrorDetails {
	
	Date date;
	String message;
	String description;
	public ErrorDetails(Date date, String message, String description) {
		super();
		this.date = date;
		this.message = message;
		this.description = description;
	}

	

}
