package com.conversion.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.conversion.model.ErrorDetails;
import com.conversion.service.INumberService;

/**
 * converting number to words
 * @author madhu
 *
 */

@RestController
public class NumberController {
	
	private static final Logger LOG = LoggerFactory.getLogger(NumberController.class);
	@Autowired
	private INumberService iNumberService;
	
	
	/**
	 * takes any integer number and converts to words
	 * @param num
	 * @return
	 * @throws Exception
	 */
	
	 @GetMapping("/convert")
	    public String converter(@RequestParam Integer num) throws Exception
	    {
		 if(num >=0 && num<999999999) {
			 LOG.info("converter, num: {}",num);		 
	        return iNumberService.converter(num);
		 }else {
			 return "Please provide valid number between 0 to 999,999,999";
		 }
	    }
	

	 /**
	  * handle any type of exceptions
	  * @param ex
	  * @param request
	  * @return
	  */
	 @ExceptionHandler(Exception.class)
	 public final ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex, WebRequest request) {
	   ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(),
	       request.getDescription(false));
	   return new ResponseEntity<ErrorDetails>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	 }
}
