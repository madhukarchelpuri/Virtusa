package com.conversion.service;

public interface INumberService {
	
String converter(Integer num)throws Exception;
}
