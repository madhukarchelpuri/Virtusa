package com.conversion.service.impl;

import org.springframework.stereotype.Service;

import com.conversion.service.INumberService;
import com.conversion.util.NumberToWords;

@Service
public class NumberServiceImpl implements INumberService{
	
	

	/**
	 * business logic to convert number to words
	 */
	
	public String converter(Integer num) throws Exception {		
		
		return NumberToWords.convert(num);
	}
	

}
